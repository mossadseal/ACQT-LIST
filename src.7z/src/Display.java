import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.ScrollPane;
import java.awt.ScrollPaneAdjustable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneLayout;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class Display extends JFrame { 


	private JTextArea textArea;
	private JScrollPane scrollPane;
	
	
	public JTextArea getdisplaypane(){
		return textArea;
		
	}
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Display frame = new Display();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Display() {
		setTitle("DISPLAY PANE");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 725, 502);
		getContentPane().setLayout(null);
				
		textArea = new JTextArea();
		textArea.setBounds(0, 0, JFrame.WIDTH, JFrame.HEIGHT);
		
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		
		
	    scrollPane = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	 	scrollPane.setBounds(0, 0, 709,464 );
	    getContentPane().add(scrollPane);
		
		
	}
	
}
