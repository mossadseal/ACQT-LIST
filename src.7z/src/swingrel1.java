import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class swingrel1 {

	private JFrame frame;
	
	public JFrame getframe(){
		
		return frame;
	}
	
	private static int p1=0;
	
	SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
	   Date date;
	   private String name;
	   private String mobileno;
	   private String e_mail;
	   private String dob;
	   private String dolm;
	   private JTextField nameField;
	   private JTextField mobnoField;
	   private JTextField mailField;
	   private JTextField birthField;
	   private JTextField meetField;
	   
	   
	   
	   
	    
	   public String getname(){
	    
	    return name;
	    }
	    
	    public void name(String s){
	    
	    name=s;
	    }
	    
	    
	     public String getmobileno(){
	    
	    return mobileno;
	    }
	    
	    public void mobileno(String s){
	    
	    mobileno=s;
	    }
	    
	    
	     public String getmail(){
	    
	    return e_mail;
	    }
	    
	    public void mail(String s){
	    
	    e_mail=s;
	    }
	    
	    
	     public String getdob(){
	    
	    return dob;
	    }
	    
	    public void dob(String s)throws Exception{
	    
	    date=df.parse(s);
	    dob=df.format(date);
	    }
	    
	    
	     public String getdolm(){
	    
	    return dolm;
	    }
	    
	    public void dolm(String s)throws Exception{
	    
	    date=df.parse(s);
	    dolm=df.format(date);
	    }
	    
	    public int getrelatives(){
	    	
	    	return p1;
	    }
	    
	    public void setrelatives(int a){
	    	
	    	p1=a;
	    }
	    
	    
	    
	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public swingrel1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 444);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(49, 43, 62, 22);
		frame.getContentPane().add(lblName);
		
		JLabel lblMobno = new JLabel("Mob.no");
		lblMobno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobno.setBounds(49, 101, 62, 22);
		frame.getContentPane().add(lblMobno);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(49, 158, 62, 22);
		frame.getContentPane().add(lblEmail);
		
		nameField = new JTextField();
		nameField.setBounds(250, 47, 264, 20);
		frame.getContentPane().add(nameField);
		nameField.setColumns(10);
		
		mobnoField = new JTextField();
		mobnoField.setBounds(250, 105, 264, 20);
		frame.getContentPane().add(mobnoField);
		mobnoField.setColumns(10);
		
		mailField = new JTextField();
		mailField.setBounds(250, 162, 264, 20);
		frame.getContentPane().add(mailField);
		mailField.setColumns(10);
		
		JButton save = new JButton("save");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				name=nameField.getText();
				mobileno=mobnoField.getText();
				e_mail=mailField.getText();
				boolean flag=true;
				
					flag=false;
				try {
					dob(birthField.getText());
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null,"invalid date format in dob");
					name=null;mobileno=null;e_mail=null;dob=null;dolm=null;
					flag=true;
				}
				try {
					dolm(meetField.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,"invalid date format in dolm");
					name=null;mobileno=null;e_mail=null;dob=null;dolm=null;flag=true;
				}
				
			
			if(!flag){	p1++;frame.dispose();}
				
			}
		});
		save.setBounds(250, 352, 89, 23);
		frame.getContentPane().add(save);
		
		JLabel lblDateOfBirth = new JLabel("Date of birth");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDateOfBirth.setBounds(52, 207, 130, 22);
		frame.getContentPane().add(lblDateOfBirth);
		
		birthField = new JTextField();
		birthField.setBounds(250, 211, 264, 20);
		frame.getContentPane().add(birthField);
		birthField.setColumns(10);
		
		JLabel lblDateOfLast = new JLabel("Date of last meet");
		lblDateOfLast.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDateOfLast.setBounds(49, 262, 156, 39);
		frame.getContentPane().add(lblDateOfLast);
		
		meetField = new JTextField();
		meetField.setBounds(250, 274, 264, 20);
		frame.getContentPane().add(meetField);
		meetField.setColumns(10);
	}
}
