import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class swingper extends JFrame{
	
   
	private JPanel contentPane;
	private JTextField textFieldname;
	private JTextField textFieldmobno;
	private JTextField textFieldmail;
	private JTextField textFielddoa;
	private JTextField textFieldcontext;
	private JTextField textFieldspecificevent;
	
	private static int p2=0;
	
	public JPanel getcontentpane(){
		
		return contentPane;
	}
	
	
	
	
	SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
	  private String name;  
	  
	  private  Date date;
	  
	  private String mobileno;  
	  
	    
	  private String e_mail;  
	  
	    
	  private String context;  
	  
	    
	  private String doa;
	  
	    
	  private String specificevent;  
	    
	  
	   public String getname(){
	    
	    return name;
	    }
	    
	    public void name(String s){
	    
	    name=s;
	    }
	    
	    
	     public String getmobileno(){
	    
	    return mobileno;
	    }
	    
	    public void mobileno(String s){
	    
	    mobileno=s;
	    }
	    
	    
	     public String getmail(){
	    
	    return e_mail;
	    }
	    
	    public void mail(String s){
	    
	    e_mail=s;
	    }
	    
	    
	    
	     public String getcontext(){
	    
	    return context;
	    }
	    
	    public void context(String s){
	    
	    context=s;
	    }
	    
	    
	    
	     public String getdoa(){
	    
	    return doa;
	    }
	    
	    public void doa(String s)throws Exception{
	    
	    date=df.parse(s);
	    doa=df.format(date);
	    }
	    
	    
	    
	     public String getspecificevent(){
	    
	    return specificevent;
	    }
	    
	    public void specificevent(String s){
	    
	    specificevent=s;
	    }
	
	    public int getpersonal(){
	    	
	    	return p2;
	    }
	    
	    public void setpersonal(int a){
	    	
	    	p2=a;
	    }
	    
	    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					swingper frame = new swingper();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public swingper() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 670, 472);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(28, 44, 62, 22);
		contentPane.add(lblName);
		
		JLabel lblMobileno = new JLabel("Mobile.no");
		lblMobileno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobileno.setBounds(28, 102, 89, 22);
		contentPane.add(lblMobileno);
		
		JLabel lblEmail = new JLabel("E_mail");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(28, 167, 89, 29);
		contentPane.add(lblEmail);
		
		JLabel lblDateOfAccquaintance = new JLabel("Date of accquaintance");
		lblDateOfAccquaintance.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDateOfAccquaintance.setBounds(28, 224, 205, 29);
		contentPane.add(lblDateOfAccquaintance);
		
		JLabel lblContext = new JLabel("Context");
		lblContext.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblContext.setBounds(28, 280, 121, 41);
		contentPane.add(lblContext);
		
		JLabel lblSpecificevent = new JLabel("SpecificEvent");
		lblSpecificevent.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSpecificevent.setBounds(30, 344, 137, 36);
		contentPane.add(lblSpecificevent);
		
		textFieldname = new JTextField();
		textFieldname.setBounds(267, 46, 358, 20);
		contentPane.add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldmobno = new JTextField();
		textFieldmobno.setBounds(267, 106, 358, 20);
		contentPane.add(textFieldmobno);
		textFieldmobno.setColumns(10);
		
		textFieldmail = new JTextField();
		textFieldmail.setBounds(267, 174, 358, 20);
		contentPane.add(textFieldmail);
		textFieldmail.setColumns(10);
		
		textFielddoa = new JTextField();
		textFielddoa.setBounds(267, 231, 358, 20);
		contentPane.add(textFielddoa);
		textFielddoa.setColumns(10);
		
		textFieldcontext = new JTextField();
		textFieldcontext.setBounds(267, 293, 358, 20);
		contentPane.add(textFieldcontext);
		textFieldcontext.setColumns(10);
		
		textFieldspecificevent = new JTextField();
		textFieldspecificevent.setBounds(267, 355, 358, 20);
		contentPane.add(textFieldspecificevent);
		textFieldspecificevent.setColumns(10);
		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				boolean flag=true;
				name=textFieldname.getText();
				mobileno=textFieldmobno.getText();
				e_mail=textFieldmail.getText();
				
				context=textFieldcontext.getText();
				specificevent=textFieldspecificevent.getText();
				
				try {
					doa(textFielddoa.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
				
					e.printStackTrace();
					flag=false;
					JOptionPane.showMessageDialog(null,"enter valid date format");
					name=null;mobileno=null;e_mail=null;context=doa=null;specificevent=null;
					
				}
				
				if(flag){p2++;dispose();}
				
				
				
			}
		});
		btnSave.setBounds(276, 400, 89, 23);
		contentPane.add(btnSave);
	}
}
