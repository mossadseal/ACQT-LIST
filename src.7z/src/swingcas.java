import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class swingcas extends JFrame {

	private JPanel contentPane;
	
	SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");   
    
	  private String name;  
	 
	  private String mobileno;  
	  
	  private Date date; 
	  
	  private String e_mail;  
	  
	  private String when;
	   
	  private String where; 
	   
	  private String circumstances;  

	  private String other; 
	  
	  private static int p4=0;
	  private JTextField textFieldname;
	  private JTextField textFieldmobno;
	  private JTextField textFieldmail;
	  private JTextField textFielddom;
	  private JTextField textFieldpom;
	  private JTextField textFieldcom;
	  private JTextField textFieldoi;
	  
	  
	  public int getcasual(){
		  
		  return p4;
	  }
	  
	  public void setcasual(int a){
		  
		  p4=a;
	  }
	  
	  
	   public String getname(){
	    
	    return name;
	    }
	    
	    public void name(String s){
	    
	    name=s;
	    }
	    
	      public String getmobileno(){
	    
	    return mobileno;
	    }
	    
	    public void mobileno(String s){
	    
	    mobileno=s;
	    }
	    
	    
	    
	    
	    
	     public String getmail(){
	    
	    return e_mail;
	    }
	    
	    public void mail(String s){
	    
	    e_mail=s;
	    }
	  
	  
	  
	  public String getwhen(){
	    
	    return when;
	    }
	    
	    public void when(String s)throws Exception{
	    
	    date=df.parse(s);
	    when=df.format(date);
	    }
	    
	    
	    
	    
	    
	    public String getwhere(){
	    
	    return where;
	    }
	    
	    public void where(String s){
	    
	    where=s;
	    }
	    
	    
	    
	    
	    
	    
	    public String getcircumstances(){
	    
	    return circumstances;
	    }
	    
	    public void circumstances(String s){
	    
	    circumstances=s;
	    }
	  
	  
	   public String getother(){
	    
	    return other;
	    }
	    
	    public void other(String s){
	    
	    other=s;
	    }
	  
	  
	  
	  
	  
	  

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					swingcas frame = new swingcas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public swingcas() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 660, 492);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(10, 23, 77, 22);
		contentPane.add(lblName);
		
		JLabel lblMobileno = new JLabel("Mobile.no");
		lblMobileno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobileno.setBounds(10, 68, 91, 35);
		contentPane.add(lblMobileno);
		
		JLabel lblEmail = new JLabel("E_mail");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(10, 126, 77, 22);
		contentPane.add(lblEmail);
		
		JLabel lblDateOfMeeting = new JLabel("Date of meeting");
		lblDateOfMeeting.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDateOfMeeting.setBounds(10, 181, 161, 35);
		contentPane.add(lblDateOfMeeting);
		
		JLabel lblPlaceOfMeeting = new JLabel("Place of meeting");
		lblPlaceOfMeeting.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPlaceOfMeeting.setBounds(10, 240, 137, 27);
		contentPane.add(lblPlaceOfMeeting);
		
		JLabel lblCircumstancesOfMeeting = new JLabel("Circumstances of meeting");
		lblCircumstancesOfMeeting.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCircumstancesOfMeeting.setBounds(10, 292, 213, 35);
		contentPane.add(lblCircumstancesOfMeeting);
		
		JLabel lblOtherInfo = new JLabel("Other info..");
		lblOtherInfo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOtherInfo.setBounds(10, 354, 137, 26);
		contentPane.add(lblOtherInfo);
		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				boolean flag=true;
				
				name=textFieldname.getText();
				
				mobileno=textFieldmobno.getText();
				
				e_mail=textFieldmail.getText();
				
				try {
					when(textFielddom.getText());
				} catch (Exception e) {
					flag=false;
					JOptionPane.showMessageDialog(null,"enter valid date format");
					
				}
				
				where=textFieldpom.getText();
				
				circumstances=textFieldcom.getText();
				
				other=textFieldoi.getText();
				
				if(flag){
					
					p4++;dispose();
				}
				
			}
		});
		btnSave.setBounds(277, 420, 89, 23);
		contentPane.add(btnSave);
		
		textFieldname = new JTextField();
		textFieldname.setBounds(289, 27, 320, 20);
		contentPane.add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldmobno = new JTextField();
		textFieldmobno.setBounds(289, 78, 320, 20);
		contentPane.add(textFieldmobno);
		textFieldmobno.setColumns(10);
		
		textFieldmail = new JTextField();
		textFieldmail.setBounds(289, 130, 320, 20);
		contentPane.add(textFieldmail);
		textFieldmail.setColumns(10);
		
		textFielddom = new JTextField();
		textFielddom.setBounds(289, 191, 320, 20);
		contentPane.add(textFielddom);
		textFielddom.setColumns(10);
		
		textFieldpom = new JTextField();
		textFieldpom.setBounds(289, 246, 320, 20);
		contentPane.add(textFieldpom);
		textFieldpom.setColumns(10);
		
		textFieldcom = new JTextField();
		textFieldcom.setBounds(289, 302, 320, 20);
		contentPane.add(textFieldcom);
		textFieldcom.setColumns(10);
		
		textFieldoi = new JTextField();
		textFieldoi.setBounds(289, 360, 320, 20);
		contentPane.add(textFieldoi);
		textFieldoi.setColumns(10);
	}

}
