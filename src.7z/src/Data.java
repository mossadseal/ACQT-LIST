import java.awt.EventQueue;

import javax.swing.*;


import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Data {

	private JFrame frmAccquaintanceManager;
	

  private LinkedList<swingrel1> relative=new LinkedList<swingrel1>();
  
  private LinkedList<swingper> personal=new LinkedList<swingper>();
  
  private LinkedList<swingpro> professional=new LinkedList<swingpro>();
   
  private LinkedList<swingcas> casual=new LinkedList<swingcas>();
  
  private JButton btnCreatePersonal;
  private JLabel lblCreateAnAccquaintance;
  private JLabel lblNewLabel;
  private JTextField textFielddelete;
  private JTextField textFieldsearch;
  
  
  
  
  
  
  
  
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Data window = new Data();
					window.frmAccquaintanceManager.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	
		
	}

	/**
	 * Create the application.
	 */
	public Data() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccquaintanceManager = new JFrame();
		frmAccquaintanceManager.setTitle("ACCQUAINTANCE MANAGER");
		frmAccquaintanceManager.setBounds(100, 100, 758, 479);
		frmAccquaintanceManager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAccquaintanceManager.getContentPane().setLayout(null); 
		
		
		relative.add(new swingrel1());
		personal.add(new swingper());
		professional.add(new swingpro());
		casual.add(new swingcas());
		
		JButton btnCreateRelatives = new JButton("create relatives");
		btnCreateRelatives.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
		
				
				relative.add(new swingrel1());
				int m=relative.get(0).getrelatives();
				relative.get(m).getframe().setVisible(true);
				 
			}
		});
		btnCreateRelatives.setBounds(262, 50, 107, 29);
		frmAccquaintanceManager.getContentPane().add(btnCreateRelatives);
		
		btnCreatePersonal = new JButton("create personal");
		btnCreatePersonal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				personal.add(new swingper());
				int m=personal.get(0).getpersonal();
				personal.get(m).setVisible(true);
				
				
			}
		});
		btnCreatePersonal.setBounds(379, 50, 107, 29);
		frmAccquaintanceManager.getContentPane().add(btnCreatePersonal);
		
		lblCreateAnAccquaintance = new JLabel("Create Accquaintance");
		lblCreateAnAccquaintance.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCreateAnAccquaintance.setBounds(10, 47, 193, 29);
		frmAccquaintanceManager.getContentPane().add(lblCreateAnAccquaintance);
		
		lblNewLabel = new JLabel("Display Accquaintance");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 122, 180, 22);
		frmAccquaintanceManager.getContentPane().add(lblNewLabel);
		
		JButton btnCreateProfesional = new JButton("create profesional");
		btnCreateProfesional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				professional.add(new swingpro());
				
				int m=professional.get(0).getprofessional();
				
				professional.get(m).setVisible(true);
				
			}
		});
		btnCreateProfesional.setBounds(496, 50, 107, 29);
		frmAccquaintanceManager.getContentPane().add(btnCreateProfesional);
		
		JButton btnCreateCasual = new JButton("create casual");
		btnCreateCasual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				casual.add(new swingcas());
				
				int m=casual.get(0).getcasual();
				
				casual.get(m).setVisible(true);
				
				
			}
		});
		btnCreateCasual.setBounds(613, 50, 107, 29);
		frmAccquaintanceManager.getContentPane().add(btnCreateCasual);
		
		JCheckBox chckbxrelatives = new JCheckBox("Relatives");
		chckbxrelatives.setBounds(262, 125, 84, 23);
		frmAccquaintanceManager.getContentPane().add(chckbxrelatives);
		
		JCheckBox chckbxpersonal = new JCheckBox("Personal");
		chckbxpersonal.setBounds(348, 125, 84, 23);
		frmAccquaintanceManager.getContentPane().add(chckbxpersonal);
		
		JCheckBox chckbxprofessional = new JCheckBox("Professional");
		chckbxprofessional.setBounds(434, 125, 84, 23);
		frmAccquaintanceManager.getContentPane().add(chckbxprofessional);
		
		JCheckBox chckbxcasual = new JCheckBox("Casual");
		chckbxcasual.setBounds(534, 125, 77, 23);
		frmAccquaintanceManager.getContentPane().add(chckbxcasual);
		
		JButton btnDisplay = new JButton("Display");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				Display dp=new Display();
				dp.setVisible(true);
				int m=0;
				
				if(chckbxrelatives.isSelected()){
					
					relative.add(new swingrel1());
				 	
				  m=relative.get(0).getrelatives();
					
				
				
					dp.getdisplaypane().append("Relatives:\n");
					
					for(int i=0;i<m;++i){
						
						dp.getdisplaypane().append(relative.get(i).getname()+"\n"+relative.get(i).getmobileno()+"\n"+relative.get(i).getmail()+"\n"+relative.get(i).getdob()+"\n"+relative.get(i).getdolm()+"\n");
						
						
					}}
					
					
					if(chckbxpersonal.isSelected()){
						
						personal.add(new swingper());	
						 m=personal.get(0).getpersonal();
			
					    dp.getdisplaypane().append("Personal:\n");
						
						for(int i=0;i<m;++i){
							
							dp.getdisplaypane().append(personal.get(i).getname()+"\n"+personal.get(i).getmobileno()+"\n"+personal.get(i).getmail()+"\n"+personal.get(i).getdoa()+"\n"+personal.get(i).getcontext()+"\n"+personal.get(i).getspecificevent()+"\n");
							
					}	
				}
					
					
					if(chckbxprofessional.isSelected()){
						
						professional.add(new swingpro());
						 m=professional.get(0).getprofessional();
							
						    dp.getdisplaypane().append("Professional:\n");
							
							for(int i=0;i<m;++i){
								
								dp.getdisplaypane().append(professional.get(i).getname()+"\n"+professional.get(i).getmobileno()+"\n"+professional.get(i).getmail()+"\n"+professional.get(i).getcommoninterests()+"\n");
								
						}	
						
						
					}
					
					if(chckbxcasual.isSelected()){
						
						casual.add(new swingcas());
						 m=casual.get(0).getcasual();
						 
						 dp.getdisplaypane().append("casual:\n");
						
						
						 for(int i=0;i<m;++i){
								
								dp.getdisplaypane().append(casual.get(i).getname()+"\n"+casual.get(i).getmobileno()+"\n"+casual.get(i).getmail()+"\n"+casual.get(i).getwhen()+"\n"+casual.get(i).getwhere()+"\n"+casual.get(i).getcircumstances()+"\n"+casual.get(i).getother()+"\n");
								
						}	
						
						
						
					}
					
					
			}
		});
		btnDisplay.setBounds(629, 125, 91, 23);
		frmAccquaintanceManager.getContentPane().add(btnDisplay);
		
		JLabel lblDeleteAccquaintance = new JLabel("Delete Accquaintance");
		lblDeleteAccquaintance.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDeleteAccquaintance.setBounds(10, 190, 180, 29);
		frmAccquaintanceManager.getContentPane().add(lblDeleteAccquaintance);
		
		textFielddelete = new JTextField();
		textFielddelete.setBounds(262, 197, 341, 20);
		frmAccquaintanceManager.getContentPane().add(textFielddelete);
		textFielddelete.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String s=textFielddelete.getText();
				int	k=relative.get(0).getrelatives();
				int l=personal.get(0).getpersonal();
				int m=professional.get(0).getprofessional();
				int n=casual.get(0).getcasual();	
					int a=0;
					int y=0;
				    for(y=0;y<k+l+m+n;y++){
				        if(y<k){
				        if(s.compareToIgnoreCase(relative.get(y).getname())==0){a=1;break;}}
				        if(a==1)break;
				         if(y>=k&&y<k+l){
				        if(s.compareToIgnoreCase(personal.get(y-k).getname())==0){a=2;break;}}
				        if(a==2)break;
				         if(y>=k+l&&y<k+l+m){
				        if(s.compareToIgnoreCase(professional.get(y-k-l).getname())==0){a=3;break;}}
				        if(a==3)break;
				         if(y>=k+l+m&&y<k+l+m+n){
				        if(s.compareToIgnoreCase(casual.get(y-k-l-m).getname())==0){a=4;break;}}
				        if(a==4)break;
				       }
				       
				       
				  
				    
				     if(a==1){
				       
				    	 relative.remove(y);
				    	 relative.add(new swingrel1());
				    int	q= relative.get(0).getrelatives();
				    relative.get(0).setrelatives(q-1);
				    							
				    	 
				       }
				       
				     if(a==2){
				    	 
				    	 personal.remove(y-k);
				    	 personal.add(new swingper());
						    int	q= personal.get(0).getpersonal();    
						    personal.get(0).setpersonal(q-1);
				       
				       }
				     
				     if(a==3){
				       
				    	 professional.remove(y-k-l);
				    	 professional.add(new swingpro());
						    int	q= professional.get(0).getprofessional();    
						    professional.get(0).setprofessional(q-1);
				        
				    
				       }
				     
				     if(a==4){
				       
				    	 casual.remove(y-k-l-m);
				    	 casual.add(new swingcas());
						    int	q= casual.get(0).getcasual();    
						    casual.get(0).setcasual(q-1);
				        
				    	 
				        
				       }
				       
				       if(a==0){JOptionPane.showMessageDialog(null,"no accquaintances with given name");}
					
				
				
				
				
				
				
			}
		});
		btnDelete.setBounds(629, 196, 91, 23);
		frmAccquaintanceManager.getContentPane().add(btnDelete);
		
		JLabel lblSearchAccquaintance = new JLabel("Search Accquaintance");
		lblSearchAccquaintance.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSearchAccquaintance.setBounds(10, 260, 193, 29);
		frmAccquaintanceManager.getContentPane().add(lblSearchAccquaintance);
		
		textFieldsearch = new JTextField();
		textFieldsearch.setBounds(262, 267, 341, 20);
		frmAccquaintanceManager.getContentPane().add(textFieldsearch);
		textFieldsearch.setColumns(10);
		
		JButton btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String s=textFieldsearch.getText();
			int	k=relative.get(0).getrelatives();
			int l=personal.get(0).getpersonal();
			int m=professional.get(0).getprofessional();
			int n=casual.get(0).getcasual();	
				int a=0;
				int y=0;
			    for(y=0;y<k+l+m+n;y++){
			        if(y<k){
			        if(s.compareToIgnoreCase(relative.get(y).getname())==0){a=1;break;}}
			        if(a==1)break;
			         if(y>=k&&y<k+l){
			        if(s.compareToIgnoreCase(personal.get(y-k).getname())==0){a=2;break;}}
			        if(a==2)break;
			         if(y>=k+l&&y<k+l+m){
			        if(s.compareToIgnoreCase(professional.get(y-k-l).getname())==0){a=3;break;}}
			        if(a==3)break;
			         if(y>=k+l+m&&y<k+l+m+n){
			        if(s.compareToIgnoreCase(casual.get(y-k-l-m).getname())==0){a=4;break;}}
			        if(a==4)break;
			       }
			       
			       
			    Display dp=new Display();
			    dp.setVisible(true);
			    
			     if(a==1){
			       
			    						
							dp.getdisplaypane().append(relative.get(y).getname()+"\n"+relative.get(y).getmobileno()+"\n"+relative.get(y).getmail()+"\n"+relative.get(y).getdob()+"\n"+relative.get(y).getdolm()+"\n");
							
			    	 
			       }
			       
			     if(a==2){
			       
			    	 dp.getdisplaypane().append(personal.get(y-k).getname()+"\n"+personal.get(y-k).getmobileno()+"\n"+personal.get(y-k).getmail()+"\n"+personal.get(y-k).getdoa()+"\n"+personal.get(y-k).getcontext()+"\n"+personal.get(y-k).getspecificevent()+"\n");
			       
			       }
			     
			     if(a==3){
			       
			    	 dp.getdisplaypane().append(professional.get(y-k-l).getname()+"\n"+professional.get(y-k-l).getmobileno()+"\n"+professional.get(y-k-l).getmail()+"\n"+professional.get(y-k-l).getcommoninterests()+"\n");
			        
			    
			       }
			     
			     if(a==4){
			       
			    	 dp.getdisplaypane().append(casual.get(y-k-l-m).getname()+"\n"+casual.get(y-k-l-m).getmobileno()+"\n"+casual.get(y-k-l-m).getmail()+"\n"+casual.get(y-k-l-m).getwhen()+"\n"+casual.get(y-k-l-m).getwhere()+"\n"+casual.get(y-k-l-m).getcircumstances()+"\n"+casual.get(y-k-l-m).getother()+"\n"); 
			        
			       }
			       
			       if(a==0){JOptionPane.showMessageDialog(null,"no accquaintances with given name");}
				
				
				
				
				
			}
		});
		btnsearch.setBounds(629, 266, 91, 23);
		frmAccquaintanceManager.getContentPane().add(btnsearch);
		
		JLabel lblSaveToFile = new JLabel("Save to file");
		lblSaveToFile.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSaveToFile.setBounds(10, 335, 180, 22);
		frmAccquaintanceManager.getContentPane().add(lblSaveToFile);
		
		JButton btnSavefile = new JButton("save");
		btnSavefile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				JFileChooser fc=new JFileChooser();
				
				fc.setVisible(true);
				
				if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
				{
					
				
				PrintWriter pw = null;
				String s=fc.getSelectedFile().getAbsolutePath();
				boolean flag=true;
					try {
				 pw = new PrintWriter(s);
					} catch (FileNotFoundException e) {
						JOptionPane.showMessageDialog(null,"File not Found");
						flag=false;
						
					}
					
					
			if(flag){	
				   
				   int  y=0;
				   int	k=relative.get(0).getrelatives();
					int l=personal.get(0).getpersonal();
					int m=professional.get(0).getprofessional();
					int n=casual.get(0).getcasual();	
				    pw.println(k);
				    while(y<k){
				    
				    pw.println("relative"+y+":");
				    
				    pw.println(relative.get(y).getname());
				     
				    pw.println(relative.get(y).getmobileno()); 
				    
				    pw.println(relative.get(y).getmail());
				       
				    pw.println(relative.get(y).getdob());  
				        
				    pw.println(relative.get(y).getdolm());
				     
				    pw.println();
				    
				    y++;}
				    
				    
				    y=0;
				    pw.println(l);
				    while(y<l){
				    
				    
				    pw.println("personal"+y+":");
				    
				    pw.println(personal.get(y).getname());
				     
				    pw.println(personal.get(y).getmobileno()); 
				    
				    pw.println(personal.get(y).getmail());
				       
				    pw.println(personal.get(y).getcontext());  
				        
				    pw.println(personal.get(y).getdoa());
				     
				    pw.println(personal.get(y).getspecificevent());
				    
				    pw.println();
				    
				    y++;
				    
				}
				y=0;    
				pw.println(m);
				while(y<m){
				    pw.println("professional"+y+":");
				    
				    pw.println(professional.get(y).getname());
				     
				    pw.println(professional.get(y).getmobileno()); 
				    
				    pw.println(professional.get(y).getmail());
				       
				    pw.println(professional.get(y).getcommoninterests());  
				        
				    pw.println();
				    
				    y++;
				}
				   
				pw.println(n);
				y=0;
				while(y<n){
				    
				    pw.println("casual"+y+":");
				    
				    pw.println(casual.get(y).getname());
				     
				    pw.println(casual.get(y).getmobileno()); 
				    
				    pw.println(casual.get(y).getmail());
				       
				    pw.println(casual.get(y).getwhen());  
				        
				    pw.println(casual.get(y).getwhere());
				     
				    pw.println(casual.get(y).getcircumstances());
				    
				    pw.println(casual.get(y).getother());
				    
				    pw.println();
				    
				    y++;
				    
				}

				    pw.close();
				    
				    
			}
			
			
			Display dp=new Display();
			
			dp.setVisible(true);
			
			dp.getdisplaypane().append("info saved to file :"+s+" \n");
			
			
			}
				
				else{
					
					JOptionPane.showMessageDialog(null, "invalid file");
				}
				
				
				
				
			}
		});
		btnSavefile.setBounds(631, 338, 89, 23);
		frmAccquaintanceManager.getContentPane().add(btnSavefile);
		
		JLabel lblReadFromFile = new JLabel("Read from file");
		lblReadFromFile.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblReadFromFile.setBounds(10, 399, 133, 29);
		frmAccquaintanceManager.getContentPane().add(lblReadFromFile);
		
		JButton btnRead = new JButton("Read");
		btnRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				boolean flag=true; 
				
				
				JFileChooser fc=new JFileChooser();
				fc.setVisible(true);
				
				if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
				
				  String s=fc.getSelectedFile().getAbsolutePath();
				    File f=new File(s);
				   Scanner myvar2=null;
				try {
					myvar2 = new Scanner(f);
				} catch (FileNotFoundException e) {
					flag=false;
					JOptionPane.showMessageDialog(null, "File not found");
				}
				    
				
				if(flag){
				    int  y=0;int a=0,k,l,m,n;
				     s=myvar2.nextLine();
				     a=Integer.parseInt(s);
				     k=a;
				     relative.add(new swingrel1());
				     relative.get(0).setrelatives(k);
				    while(y<a){
				     
				     s=myvar2.nextLine();
				    relative.add(new swingrel1());
				     
				    relative.get(y).name(myvar2.nextLine());
				     
				    relative.get(y).mobileno(myvar2.nextLine()); 
				    
				    relative.get(y).mail(myvar2.nextLine());
				       
				    try {
						relative.get(y).dob(myvar2.nextLine());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  
				        
				    try {
						relative.get(y).dolm(myvar2.nextLine());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				     
				    s=myvar2.nextLine();
				    
				    y++;}
				    
				    
				    y=0;
				     s=myvar2.nextLine();
				     a=Integer.parseInt(s);
				     l=a;
				     personal.add(new swingper());
				     personal.get(0).setpersonal(l);
				    while(y<a){
				    
				    
				    s=myvar2.nextLine();
				    personal.add(new swingper());
				    
				    personal.get(y).name(myvar2.nextLine());
				     
				    personal.get(y).mobileno(myvar2.nextLine()); 
				    
				    personal.get(y).mail(myvar2.nextLine());
				       
				    personal.get(y).context(myvar2.nextLine());  
				        
				    try {
						personal.get(y).doa(myvar2.nextLine());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				     
				    personal.get(y).specificevent(myvar2.nextLine());
				    
				    s=myvar2.nextLine();
				    
				    y++;
				    
				}
				y=0;    
				s=myvar2.nextLine();
				a=Integer.parseInt(s);
				m=a;
				professional.add(new swingpro());
				professional.get(0).setprofessional(m);
				while(y<a){
	 			    
				    s=myvar2.nextLine();
				    professional.add(new swingpro());
				    professional.get(y).name(myvar2.nextLine());
				     
				    professional.get(y).mobileno(myvar2.nextLine()); 
				    
				    professional.get(y).mail(myvar2.nextLine());
				       
	 			    professional.get(y).commoninterests(myvar2.nextLine());  
				        
				    s=myvar2.nextLine();
				    
				    y++;
				}

				y=0;
				s=myvar2.nextLine();
				a=Integer.parseInt(s);
				n=a;
				casual.add(new swingcas());
				casual.get(0).setcasual(n);
				while(y<a){
				    
				    
				    s=myvar2.nextLine();
				    casual.add(new swingcas());
				    casual.get(y).name(myvar2.nextLine());
				     
				    casual.get(y).mobileno(myvar2.nextLine()); 
				    
				    casual.get(y).mail(myvar2.nextLine());
				       
				    try {
						casual.get(y).when(myvar2.nextLine());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  
				        
				    casual.get(y).where(myvar2.nextLine());
				     
				    casual.get(y).circumstances(myvar2.nextLine());
				    
				    casual.get(y).other(myvar2.nextLine());
				    
				    s=myvar2.nextLine();
				    
				    y++;
				    
				}

				myvar2.close();
				
				Display dp=new Display();
				
				dp.setVisible(true);
				
				//dp.getdisplaypane().setText("file"+textFieldreadfile.getText()+"read successfully"+"\n");
				}}
				
			}
		});
		btnRead.setBounds(631, 403, 89, 23);
		frmAccquaintanceManager.getContentPane().add(btnRead);
	}
}
