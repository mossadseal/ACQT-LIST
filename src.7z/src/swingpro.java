import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class swingpro extends JFrame {

	private JPanel contentPane;
	
	
	 private String name;  
	 
	  
	  private String mobileno;  
	  
	    
	  private String e_mail;  
	  
	  private String commoninterests;  
	  private JTextField textFieldname;
	  private JTextField textFieldmobileno;
	  private JTextField textFieldmail;
	  private JTextField textFieldci;
	    
	  private static int p3=0;
	  
	  public int getprofessional(){
		  
		  return p3;
	  }
	  
	  public void setprofessional(int a){
		  p3=a;
		  
	  }
	  
	  
	     public String getname(){
	    
	    return name;
	    }
	    
	    public void name(String s){
	    
	    name=s;
	    }
	    
	    
	     public String getmobileno(){
	    
	    return mobileno;
	    }
	    
	    public void mobileno(String s){
	    
	    mobileno=s;
	    }
	    
	    
	    
	    
	    
	     public String getmail(){
	    
	    return e_mail;
	    }
	    
	    public void mail(String s){
	    
	    e_mail=s;
	    }
	    
	    
	    
	    
	   public String getcommoninterests(){
	    
	    return commoninterests;
	    }
	    
	    public void commoninterests(String s){
	    
	    commoninterests=s;
	    }  
	    
	    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					swingpro frame = new swingpro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public swingpro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 599, 387);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(10, 53, 78, 22);
		contentPane.add(lblName);
		
		JLabel lblMobileno = new JLabel("Mobile.no");
		lblMobileno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobileno.setBounds(10, 122, 95, 22);
		contentPane.add(lblMobileno);
		
		JLabel lblEmail = new JLabel("E_mail");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(10, 189, 78, 22);
		contentPane.add(lblEmail);
		
		JLabel lblCommonInterests = new JLabel("Common Interests");
		lblCommonInterests.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCommonInterests.setBounds(10, 256, 152, 32);
		contentPane.add(lblCommonInterests);
		
		textFieldname = new JTextField();
		textFieldname.setBounds(203, 57, 332, 20);
		contentPane.add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldmobileno = new JTextField();
		textFieldmobileno.setBounds(203, 126, 332, 20);
		contentPane.add(textFieldmobileno);
		textFieldmobileno.setColumns(10);
		
		textFieldmail = new JTextField();
		textFieldmail.setBounds(203, 193, 332, 20);
		contentPane.add(textFieldmail);
		textFieldmail.setColumns(10);
		
		textFieldci = new JTextField();
		textFieldci.setBounds(203, 256, 332, 20);
		contentPane.add(textFieldci);
		textFieldci.setColumns(10);
		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
								
				boolean flag=true;
				
				name=textFieldname.getText();
				
				if(name==null){JOptionPane.showMessageDialog(null,"atleast name should be mentioned");flag=false;}
				
				mobileno=textFieldmobileno.getText();
				
				e_mail=textFieldmail.getText();
				
				commoninterests=textFieldci.getText();
				
				if(flag){p3++;
			
				dispose();}
			
			}
		});
		btnSave.setBounds(239, 308, 89, 23);
		contentPane.add(btnSave);
	}

}
